﻿namespace classResult_11a_11
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxClass = new System.Windows.Forms.TextBox();
            this.textBoxNo = new System.Windows.Forms.TextBox();
            this.textBoxIme = new System.Windows.Forms.TextBox();
            this.textBoxMath = new System.Windows.Forms.TextBox();
            this.textBoxBEL = new System.Windows.Forms.TextBox();
            this.textBoxFor = new System.Windows.Forms.TextBox();
            this.textBoxPhys = new System.Windows.Forms.TextBox();
            this.textBoxChem = new System.Windows.Forms.TextBox();
            this.textBoxBio = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.button_Izch = new System.Windows.Forms.Button();
            this.button_Safe = new System.Windows.Forms.Button();
            this.button_Find = new System.Windows.Forms.Button();
            this.button_izch_sreden = new System.Windows.Forms.Button();
            this.label_sreden = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBoxClass
            // 
            this.textBoxClass.Location = new System.Drawing.Point(50, 12);
            this.textBoxClass.Name = "textBoxClass";
            this.textBoxClass.Size = new System.Drawing.Size(20, 20);
            this.textBoxClass.TabIndex = 0;
            this.textBoxClass.TextChanged += new System.EventHandler(this.textBoxClass_TextChanged);
            // 
            // textBoxNo
            // 
            this.textBoxNo.Location = new System.Drawing.Point(103, 12);
            this.textBoxNo.Name = "textBoxNo";
            this.textBoxNo.Size = new System.Drawing.Size(20, 20);
            this.textBoxNo.TabIndex = 1;
            this.textBoxNo.TextChanged += new System.EventHandler(this.textBoxNo_TextChanged);
            // 
            // textBoxIme
            // 
            this.textBoxIme.Location = new System.Drawing.Point(159, 12);
            this.textBoxIme.Name = "textBoxIme";
            this.textBoxIme.Size = new System.Drawing.Size(135, 20);
            this.textBoxIme.TabIndex = 2;
            // 
            // textBoxMath
            // 
            this.textBoxMath.Location = new System.Drawing.Point(74, 94);
            this.textBoxMath.Name = "textBoxMath";
            this.textBoxMath.Size = new System.Drawing.Size(20, 20);
            this.textBoxMath.TabIndex = 3;
            // 
            // textBoxBEL
            // 
            this.textBoxBEL.Location = new System.Drawing.Point(74, 41);
            this.textBoxBEL.Name = "textBoxBEL";
            this.textBoxBEL.Size = new System.Drawing.Size(20, 20);
            this.textBoxBEL.TabIndex = 4;
            this.textBoxBEL.TextChanged += new System.EventHandler(this.textBoxBEL_TextChanged);
            // 
            // textBoxFor
            // 
            this.textBoxFor.Location = new System.Drawing.Point(74, 68);
            this.textBoxFor.Name = "textBoxFor";
            this.textBoxFor.Size = new System.Drawing.Size(20, 20);
            this.textBoxFor.TabIndex = 5;
            this.textBoxFor.TextChanged += new System.EventHandler(this.textBoxFor_TextChanged);
            // 
            // textBoxPhys
            // 
            this.textBoxPhys.Location = new System.Drawing.Point(150, 41);
            this.textBoxPhys.Name = "textBoxPhys";
            this.textBoxPhys.Size = new System.Drawing.Size(20, 20);
            this.textBoxPhys.TabIndex = 6;
            // 
            // textBoxChem
            // 
            this.textBoxChem.Location = new System.Drawing.Point(150, 68);
            this.textBoxChem.Name = "textBoxChem";
            this.textBoxChem.Size = new System.Drawing.Size(20, 20);
            this.textBoxChem.TabIndex = 7;
            // 
            // textBoxBio
            // 
            this.textBoxBio.Location = new System.Drawing.Point(150, 94);
            this.textBoxBio.Name = "textBoxBio";
            this.textBoxBio.Size = new System.Drawing.Size(20, 20);
            this.textBoxBio.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(32, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "Клас";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(76, 15);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(21, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "No";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(129, 15);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "Име";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 44);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 13);
            this.label4.TabIndex = 12;
            this.label4.Text = "БЕЛ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 71);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(61, 13);
            this.label5.TabIndex = 13;
            this.label5.Text = "Чужд език";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 97);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(30, 13);
            this.label6.TabIndex = 14;
            this.label6.Text = "Мат.";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(100, 44);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(48, 13);
            this.label7.TabIndex = 15;
            this.label7.Text = "Физика";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(100, 71);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(40, 13);
            this.label8.TabIndex = 16;
            this.label8.Text = "Химия";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(100, 97);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(26, 13);
            this.label9.TabIndex = 17;
            this.label9.Text = "Био";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(12, 129);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(75, 13);
            this.label10.TabIndex = 18;
            this.label10.Text = "Среден успех";
            // 
            // button_Izch
            // 
            this.button_Izch.Location = new System.Drawing.Point(176, 41);
            this.button_Izch.Name = "button_Izch";
            this.button_Izch.Size = new System.Drawing.Size(118, 20);
            this.button_Izch.TabIndex = 19;
            this.button_Izch.Text = "Изчисли";
            this.button_Izch.UseVisualStyleBackColor = true;
            this.button_Izch.Click += new System.EventHandler(this.button_Izch_Click);
            // 
            // button_Safe
            // 
            this.button_Safe.Location = new System.Drawing.Point(176, 68);
            this.button_Safe.Name = "button_Safe";
            this.button_Safe.Size = new System.Drawing.Size(118, 20);
            this.button_Safe.TabIndex = 20;
            this.button_Safe.Text = "Запази";
            this.button_Safe.UseVisualStyleBackColor = true;
            this.button_Safe.Click += new System.EventHandler(this.button_Safe_Click);
            // 
            // button_Find
            // 
            this.button_Find.Location = new System.Drawing.Point(176, 94);
            this.button_Find.Name = "button_Find";
            this.button_Find.Size = new System.Drawing.Size(118, 20);
            this.button_Find.TabIndex = 21;
            this.button_Find.Text = "Търси";
            this.button_Find.UseVisualStyleBackColor = true;
            this.button_Find.Click += new System.EventHandler(this.button_Find_Click);
            // 
            // button_izch_sreden
            // 
            this.button_izch_sreden.Location = new System.Drawing.Point(150, 125);
            this.button_izch_sreden.Name = "button_izch_sreden";
            this.button_izch_sreden.Size = new System.Drawing.Size(144, 20);
            this.button_izch_sreden.TabIndex = 22;
            this.button_izch_sreden.Text = "Изчисли среден";
            this.button_izch_sreden.UseVisualStyleBackColor = true;
            this.button_izch_sreden.Click += new System.EventHandler(this.button_izch_sreden_Click);
            // 
            // label_sreden
            // 
            this.label_sreden.AutoSize = true;
            this.label_sreden.Location = new System.Drawing.Point(100, 129);
            this.label_sreden.Name = "label_sreden";
            this.label_sreden.Size = new System.Drawing.Size(41, 13);
            this.label_sreden.TabIndex = 23;
            this.label_sreden.Text = "label11";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(176, 157);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(118, 25);
            this.button1.TabIndex = 24;
            this.button1.Text = "Запази файл";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(16, 157);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(118, 25);
            this.button2.TabIndex = 25;
            this.button2.Text = "Зареди файл";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(307, 258);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label_sreden);
            this.Controls.Add(this.button_izch_sreden);
            this.Controls.Add(this.button_Find);
            this.Controls.Add(this.button_Safe);
            this.Controls.Add(this.button_Izch);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxBio);
            this.Controls.Add(this.textBoxChem);
            this.Controls.Add(this.textBoxPhys);
            this.Controls.Add(this.textBoxFor);
            this.Controls.Add(this.textBoxBEL);
            this.Controls.Add(this.textBoxMath);
            this.Controls.Add(this.textBoxIme);
            this.Controls.Add(this.textBoxNo);
            this.Controls.Add(this.textBoxClass);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxClass;
        private System.Windows.Forms.TextBox textBoxNo;
        private System.Windows.Forms.TextBox textBoxIme;
        private System.Windows.Forms.TextBox textBoxMath;
        private System.Windows.Forms.TextBox textBoxBEL;
        private System.Windows.Forms.TextBox textBoxFor;
        private System.Windows.Forms.TextBox textBoxPhys;
        private System.Windows.Forms.TextBox textBoxChem;
        private System.Windows.Forms.TextBox textBoxBio;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button button_Izch;
        private System.Windows.Forms.Button button_Safe;
        private System.Windows.Forms.Button button_Find;
        private System.Windows.Forms.Button button_izch_sreden;
        private System.Windows.Forms.Label label_sreden;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
    }
}

