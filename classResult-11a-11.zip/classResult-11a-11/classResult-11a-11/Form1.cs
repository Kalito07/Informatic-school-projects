﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace classResult_11a_11
{
    public partial class Form1 : Form
    {
        Student NewStud = new Student();
        Student[] classof = new Student[27];
        public Form1()
        {
            InitializeComponent();
        }

        private void textBoxClass_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void textBoxBEL_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBoxFor_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            label_sreden.Hide();
            for (int i = 1; i < 27; i++)
            {
                classof[i] = new Student();
            }
            
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBoxNo_TextChanged(object sender, EventArgs e)
        {

        }

        private void button_Izch_Click(object sender, EventArgs e)
        {
            textBoxClass.Text = "";
            textBoxNo.Text = "";
            textBoxIme.Text = "";
            textBoxBEL.Text = "";
            textBoxFor.Text = "";
            textBoxMath.Text = "";
            textBoxPhys.Text = "";
            textBoxChem.Text = "";
            textBoxBio.Text = "";
            label_sreden.Hide();
        }

        private void button_Safe_Click(object sender, EventArgs e)
        {
            try
            {
                if (int.Parse(textBoxNo.Text) > 0 && int.Parse(textBoxNo.Text) < 27)
                {
                    classof[int.Parse(textBoxNo.Text)].Id = int.Parse(textBoxNo.Text);
                    classof[int.Parse(textBoxNo.Text)].Klas = textBoxClass.Text;
                    classof[int.Parse(textBoxNo.Text)].Ime = textBoxIme.Text;
                    classof[int.Parse(textBoxNo.Text)].OBel = double.Parse(textBoxBEL.Text);
                    classof[int.Parse(textBoxNo.Text)].OMath = double.Parse(textBoxMath.Text);
                    classof[int.Parse(textBoxNo.Text)].OForeign = double.Parse(textBoxFor.Text);
                    classof[int.Parse(textBoxNo.Text)].OPhys = double.Parse(textBoxPhys.Text);
                    classof[int.Parse(textBoxNo.Text)].OChem = double.Parse(textBoxChem.Text);
                    classof[int.Parse(textBoxNo.Text)].OBio = double.Parse(textBoxBio.Text);
                }
            }
            catch(Exception exp)
            {
                MessageBox.Show(exp.Message);
            }
        }

        private void button_izch_sreden_Click(object sender, EventArgs e)
        {
            double sredno = classof[int.Parse(textBoxNo.Text)].CalcSr();
            label_sreden.Text = Convert.ToString(Math.Round(sredno, 2));
            label_sreden.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                StreamWriter w = new StreamWriter("Class.txt", false, Encoding.GetEncoding("Unicode"));
                for (int i = 1; i < 27; i++)
                {
                    w.Write($"{classof[i].Klas} ");
                    w.Write($"{classof[i].Id} ");
                    w.Write($"{classof[i].Ime} ");
                    w.Write($"{classof[i].OBel} ");
                    w.Write($"{classof[i].OForeign} ");
                    w.Write($"{classof[i].OMath} ");
                    w.Write($"{classof[i].OPhys} ");
                    w.Write($"{classof[i].OChem} ");
                    w.WriteLine($"{classof[i].OBio} ");
                }
                w.Close();
            }
            catch(FileNotFoundException)
            {
                MessageBox.Show("Не намерен файл!");
            }
            catch(Exception exp)
            {
                MessageBox.Show(exp.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                StreamReader r = new StreamReader("Class.txt", Encoding.GetEncoding("Unicode"));
                for (int i = 1; i < 27; i++)
                {
                    string line = r.ReadLine();
                    string[] student = line.Split(' ').ToArray();
                    classof[i].Klas = student[0];
                    classof[i].Id = int.Parse(student[1]);
                    classof[i].Ime = student[2];
                    classof[i].OBel = double.Parse(student[3]);
                    classof[i].OForeign = double.Parse(student[4]);
                    classof[i].OMath = double.Parse(student[5]);
                    classof[i].OPhys = double.Parse(student[6]);
                    classof[i].OChem = double.Parse(student[7]);
                    classof[i].OBio = double.Parse(student[8]);
                }
                r.Close();
            }
            catch(FileNotFoundException)
            {
                MessageBox.Show("Не намерен файл!");
            }
            catch(Exception exp)
            {
                MessageBox.Show(exp.Message);
            }
        }

        private void button_Find_Click(object sender, EventArgs e)
        {
            try
            {
                int No = int.Parse(textBoxNo.Text);
                textBoxClass.Text = classof[No].Klas;
                textBoxIme.Text = classof[No].Ime;
                textBoxBEL.Text = classof[No].Klas;
                textBoxMath.Text = Convert.ToString(classof[No].OMath);
                textBoxFor.Text = Convert.ToString(classof[No].OForeign);
                textBoxPhys.Text = Convert.ToString(classof[No].OPhys);
                textBoxChem.Text = Convert.ToString(classof[No].OChem);
                textBoxBio.Text = Convert.ToString(classof[No].OBio);
            }
            catch(Exception exp)
            {
                MessageBox.Show(exp.Message);
            }
        }
    }
}
