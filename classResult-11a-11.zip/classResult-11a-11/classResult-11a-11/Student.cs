﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace classResult_11a_11
{
    class Student
    {
        private string klas;
        public string Klas
        {
            set { this.klas = value; }
            get { return this.klas; }
        }
        private int id;
        public int Id
        {
            set { this.id = value; }
            get { return this.id; }
        }
        private string ime;
        public string Ime
        {
            set { this.ime = value; }
            get { return this.ime; }
        }
        private double oBel, oMath, oForeign, oPhys, oChem, oBio;
        public double OBel
        {
            set { if (value >= 2 && value <= 6) { this.oBel = value; } else { throw new Exception("Грешно въведена оценка!"); } }
            get { return this.oBel; }
        }
        public double OMath
        {
            set { if (value >= 2 && value <= 6) { this.oMath = value; } else { throw new Exception("Грешно въведена оценка!"); } }
            get { return this.oMath; }
        }
        public double OForeign
        {
            set { if (value >= 2 && value <= 6) { this.oForeign = value; } else { throw new Exception("Грешно въведена оценка!"); } }
            get { return this.oForeign; }
        }
        public double OPhys
        {
            set { if (value >= 2 && value <= 6) { this.oPhys = value; } else { throw new Exception("Грешно въведена оценка!"); } }
            get { return this.oPhys; }
        }
        public double OChem
        {
            set { if (value >= 2 && value <= 6) { this.oChem = value; } else { throw new Exception("Грешно въведена оценка!"); } }
            get { return this.oChem; }
        }
        public double OBio
        {
            set { if (value >= 2 && value <= 6) { this.oBio = value; } else { throw new Exception("Грешно въведена оценка!"); } }
            get { return this.oBio; }
        }
        public Student()
        {
            this.ime = "Nqma";
            this.klas = "Nqma";
            this.id = 0;
            this.oBel = 0;
            this.oMath = 0;
            this.oForeign = 0;
            this.oPhys = 0;
            this.oBio = 0;
            this.oChem = 0;
        }
        public Student(string klas, int id, string ime, double obel, double omath, double ofor, double ophys, double obio, double ochem)
        {
            this.ime = ime;
            this.klas = klas;
            this.id = id;
            this.oBel = obel;
            this.oMath = omath;
            this.oForeign = ofor;
            this.oPhys = ophys;
            this.oBio = obio;
            this.oChem = ochem;
        }
        public Student(Student a)
        {
            this.klas = a.Klas;
            this.id = a.Id;
            this.ime = a.Ime;
            this.oBel = a.oBel;
            this.oMath = a.oMath;
            this.oForeign = a.oForeign;
            this.oPhys = a.oPhys;
            this.oBio = a.oBio;
            this.oChem = a.oChem;
        }
        private double sredno;
        public double Sredno
        {
            set { this.sredno = value; }
            get { return this.sredno; }
        }
        public double CalcSr()
        {
            this.sredno = (this.OMath + this.OBel + this.OForeign + this.OBio + this.OPhys + this.OChem) / 6;
            return this.sredno;
        }
    }
}
